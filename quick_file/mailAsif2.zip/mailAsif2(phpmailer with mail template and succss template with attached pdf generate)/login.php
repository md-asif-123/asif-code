<?php


?>

<html>
<body>
<form name='regForm' action='' method='post' enctype='multipart/form-data'>
<table align='center' border='2' width='30%' cellpadding='0' cellspacing='6'>

<tr><td colspan='2' bgcolor='#5478966' align='center'><b>Login Form</b></td></tr>

<tr><td>Email</td><td><input type='text' name='email'></td></tr>
<tr><td>Password</td><td><input type='password' name='password'></td></tr>

<tr><td align='center' bgcolor='#5478966' colspan='2'><input type='submit' name='submit' value='LOGIN'></td></tr>
</table>
</form>
</body>
</html> 

